import { useEffect } from "react";
import { useStore } from "./store";
import { useUiStore } from "./uistore";
import { useGlobalHotkeys } from "./lib/hotkeys";
import { AuthBanner } from "./components/AuthBanner";
import { Sidebar } from "./components/Sidebar";
import { Board } from "./components/Board";
import { ListView } from "./components/ListView";
import { CalendarView } from "./components/CalendarView";
import { TopChrome } from "./components/TopChrome";
import { ReviewPanel } from "./components/ReviewPanel";
import { DetailPanel } from "./components/DetailPanel";
import { CommandPalette } from "./components/CommandPalette";
import { QuickSwitcher } from "./components/QuickSwitcher";
import { ShortcutsCheatsheet } from "./components/ShortcutsCheatsheet";
import { FocusView } from "./components/FocusView";

export function App() {
  const bootstrap = useStore((s) => s.bootstrap);
  const theme = useUiStore((s) => s.theme);
  const openTicketId = useUiStore((s) => s.openTicketId);
  const viewMode = useUiStore((s) => s.viewMode);

  useGlobalHotkeys();

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  return (
    <div
      className="h-screen flex flex-col bg-background text-foreground"
      data-theme={theme}
    >
      <AuthBanner />
      <div className="flex-1 flex min-h-0">
        <Sidebar />
        <main className="relative flex-1 flex flex-col min-w-0">
          <TopChrome />
          {/* Board stays mounted under the detail panel so the slide-in
              feels like an overlay, not a navigation. */}
          {viewMode === "list" ? (
            <ListView />
          ) : viewMode === "calendar" ? (
            <CalendarView />
          ) : (
            <Board />
          )}
          {/* Slide-in detail panel — handoff §Ticket Detail Panel.
              440px, animated, backdrop fade. Wraps the existing
              ReviewPanel so all merge/diff/iterate behavior is intact. */}
          <DetailPanel ticketId={openTicketId}>
            {openTicketId && <ReviewPanel ticketId={openTicketId} />}
          </DetailPanel>
        </main>
      </div>
      <CommandPalette />
      <QuickSwitcher />
      <ShortcutsCheatsheet />
      <FocusView />
    </div>
  );
}
