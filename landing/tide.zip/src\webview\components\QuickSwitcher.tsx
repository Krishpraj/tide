import { Command } from "cmdk";
import { Search } from "lucide-react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { useUiStore } from "../uistore";
import { useStore } from "../store";
import { StatusIcon } from "../lib/status";

/**
 * "Jump to" — fuzzy search over tickets, opened from the top-chrome search
 * pill or via ⌘P. Custom dialog wrapper so we can match the paper-on-water
 * aesthetic (tide-tinted overlay, paper card, no close-X chrome) instead of
 * the generic Dialog primitive used for forms.
 */
export function QuickSwitcher() {
  const open = useUiStore((s) => s.quickSwitcherOpen);
  const setOpen = useUiStore((s) => s.setQuickSwitcherOpen);
  const openTicket = useUiStore((s) => s.openTicket);
  const tickets = useStore((s) => s.tickets);
  const repos = useStore((s) => s.repos);

  return (
    <DialogPrimitive.Root open={open} onOpenChange={setOpen}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-tide-deep/30 backdrop-blur-[2px] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
        <DialogPrimitive.Content
          data-testid="quick-switcher"
          className="fixed left-1/2 top-[18%] z-50 w-[min(560px,92vw)] -translate-x-1/2 rounded-[14px] bg-card shadow-tide-lift overflow-hidden data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95"
        >
          <DialogPrimitive.Title className="sr-only">
            Jump to ticket
          </DialogPrimitive.Title>
          <Command
            className="bg-transparent"
            filter={(value, search) => {
              const v = value.toLowerCase();
              const s = search.toLowerCase().trim();
              if (!s) return 1;
              return v.includes(s) ? 1 : 0;
            }}
          >
            <div className="flex items-center gap-2 border-b border-black/[0.06] px-3.5 h-11">
              <Search className="h-4 w-4 text-tide-deep/45 shrink-0" />
              <Command.Input
                placeholder="Jump to ticket or repo…"
                className="flex-1 bg-transparent border-0 text-[13.5px] text-tide-deep placeholder:text-tide-deep/40 focus:outline-none"
                data-testid="quick-switcher-input"
              />
              <kbd className="inline-flex items-center gap-0.5 rounded bg-black/[0.04] px-1.5 py-0.5 font-mono text-[10px] text-tide-deep/55">
                Esc
              </kbd>
            </div>
            <Command.List className="max-h-[360px] overflow-y-auto p-1.5">
              <Command.Empty className="px-3 py-10 text-center text-[12px] text-tide-deep/45 italic">
                No matching tickets.
              </Command.Empty>
              {tickets.length > 0 && (
                <Command.Group
                  heading="Tickets"
                  className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:pt-1 [&_[cmdk-group-heading]]:pb-1 [&_[cmdk-group-heading]]:text-[11px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:text-tide-deep/55"
                >
                  {tickets.map((t) => {
                    const repo = t.repoId
                      ? repos.find((r) => r.id === t.repoId)
                      : null;
                    return (
                      <Command.Item
                        key={t.id}
                        value={`${t.title} TID-${t.id.slice(-4)} ${repo?.name ?? ""}`}
                        onSelect={() => {
                          openTicket(t.id);
                          setOpen(false);
                        }}
                        data-testid={`qs-ticket-${t.title.replace(/\s+/g, "-")}`}
                        className="group flex items-center gap-2.5 rounded-[7px] px-2 py-1.5 text-[12.5px] cursor-pointer data-[selected=true]:bg-tide/[0.08]"
                      >
                        <StatusIcon status={t.status} className="h-3.5 w-3.5 shrink-0" />
                        <span className="font-mono tabular-nums text-[10.5px] text-tide-deep/45 w-[58px] shrink-0">
                          TID-{t.id.slice(-4).toUpperCase()}
                        </span>
                        <span className="flex-1 truncate text-tide-deep group-data-[selected=true]:text-tide-deep">
                          {t.title}
                        </span>
                        {repo && (
                          <span className="hidden sm:inline-flex items-center text-[10.5px] text-tide font-mono">
                            {repo.name}
                          </span>
                        )}
                      </Command.Item>
                    );
                  })}
                </Command.Group>
              )}
            </Command.List>
          </Command>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}
