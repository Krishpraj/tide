// Captures an animated GIF of the real Tide app — populated with a curated
// demo dataset, with periodic status changes to drive on-screen motion —
// and writes it to landing/demo.gif so the marketing landing page can embed
// an actual product demo (not a recreation).
//
// Frames are captured with page.screenshot() at a fixed cadence, decoded
// with pngjs, and encoded into a GIF with gifenc — no ffmpeg required.
//
// Run with:
//   bun playwright test tests/e2e/landing-capture.spec.ts
// The existing playwright.config.ts spins up the dev bridge in stub mode
// and Vite automatically.

import { test, type Page } from "@playwright/test";
import { mkdirSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __thisFile = fileURLToPath(import.meta.url);
import { PNG } from "pngjs";
import gifencPkg from "gifenc";
const { GIFEncoder, quantize, applyPalette } = gifencPkg as unknown as {
  GIFEncoder: () => {
    writeFrame: (
      index: Uint8Array,
      width: number,
      height: number,
      opts: { palette: number[][]; delay?: number },
    ) => void;
    finish: () => void;
    bytes: () => Uint8Array;
  };
  quantize: (rgba: Uint8Array, max: number, opts?: { format?: string }) => number[][];
  applyPalette: (rgba: Uint8Array, palette: number[][], format?: string) => Uint8Array;
};
import { resetServerState } from "./helpers/reset";
import { makeTestRepo } from "./helpers/testRepo";

async function rpc<T>(page: Page, method: string, body: unknown): Promise<T> {
  const r = await page.request.post(`/rpc/${method}`, {
    data: body,
    headers: { "content-type": "application/json" },
    timeout: 60_000,
  });
  if (!r.ok()) {
    throw new Error(`rpc ${method} failed: ${await r.text()}`);
  }
  const j = (await r.json()) as { ok: true; result: T };
  return j.result;
}

type Status = "triage" | "backlog" | "queued" | "in_progress" | "review";

test("capture landing-page GIF of real Tide app", async ({ page }) => {
  test.setTimeout(240_000);
  test.slow();

  // Preflight: wait for the bridge to be ready before any RPC. Vite's
  // first compile + bun bridge boot on Windows can take a while.
  for (let i = 0; i < 60; i++) {
    const r = await page.request.get("/health").catch(() => null);
    if (r && r.ok()) break;
    await page.waitForTimeout(1000);
  }

  await resetServerState(page);
  // Force authed state so the red auth banner stays hidden.
  await page.request.post("/rpc/__setAuthOverride", {
    data: { ok: true, source: "cli" },
  });

  // Three repos in the sidebar.
  const repoTide  = await rpc<{ id: string }>(page, "addRepoLocal", { path: makeTestRepo("tide"),               projectId: "default" });
  const repoSdk   = await rpc<{ id: string }>(page, "addRepoLocal", { path: makeTestRepo("claude-agent-sdk"),   projectId: "default" });
  const repoInfra = await rpc<{ id: string }>(page, "addRepoLocal", { path: makeTestRepo("infra-pipeline"),     projectId: "default" });

  // Labels matching the in-app `labelt.*` tokens.
  const lblDesign = await rpc<{ id: string }>(page, "createLabel", { projectId: "default", name: "design", color: "#7aa8b8" });
  const lblBug    = await rpc<{ id: string }>(page, "createLabel", { projectId: "default", name: "bug",    color: "#b88a8a" });
  const lblPerf   = await rpc<{ id: string }>(page, "createLabel", { projectId: "default", name: "perf",   color: "#c89b6a" });
  const lblEng    = await rpc<{ id: string }>(page, "createLabel", { projectId: "default", name: "eng",    color: "#8aa890" });

  type Seed = {
    title: string; repoId: string; status: Status; desc: string;
    labels?: string[]; priority?: 0|1|2|3|4; estimate?: "XS"|"S"|"M"|"L"|"XL";
  };

  const seeds: Seed[] = [
    { title: "Migrate billing endpoints to axum",       repoId: repoSdk.id,   status: "triage",      desc: "Move /v1/billing/* off express.", labels: [lblEng.id],   priority: 3, estimate: "L" },
    { title: "LSP hover positioning off-screen",        repoId: repoTide.id,  status: "triage",      desc: "Hovercards clip near right edge.", labels: [lblBug.id],   priority: 2, estimate: "S" },
    { title: "Add multicursor support in search",       repoId: repoTide.id,  status: "backlog",     desc: "Multicursor in global search.",    labels: [lblDesign.id], priority: 1, estimate: "M" },
    { title: "Workspace close button hidden",           repoId: repoTide.id,  status: "backlog",     desc: "Overflow hides the X.",            labels: [lblBug.id],   priority: 2, estimate: "XS" },
    { title: "Refactor project tree diffing",           repoId: repoTide.id,  status: "backlog",     desc: "Nested project move diffs.",       labels: [lblEng.id],   priority: 1, estimate: "L" },
    { title: "AccessKit support in GPUI elements",      repoId: repoTide.id,  status: "queued",      desc: "Expose element roles.",            labels: [lblEng.id],   priority: 2, estimate: "L" },
    { title: "Rust SDK pagination — first pass",        repoId: repoSdk.id,   status: "queued",      desc: "Streaming pagination.",            labels: [lblEng.id],   priority: 2, estimate: "M" },
    { title: "Fix panic in buffer rope on large paste", repoId: repoTide.id,  status: "in_progress", desc: "Rope split panics on 4MB+ pastes.", labels: [lblBug.id, lblPerf.id], priority: 4, estimate: "S" },
    { title: "Add vim motion for surround pairs",       repoId: repoTide.id,  status: "in_progress", desc: "Add ds/cs/ys motions.",            labels: [lblEng.id],   priority: 2, estimate: "M" },
    { title: "TanStack query keys for teams",           repoId: repoSdk.id,   status: "review",      desc: "+43 -2 across 4 files.",           labels: [lblEng.id],   priority: 2, estimate: "M" },
    { title: "Stale cache on org memberships",          repoId: repoInfra.id, status: "review",      desc: "+2 -127. Removes legacy cache.",   labels: [lblBug.id],   priority: 3, estimate: "S" },
  ];

  const ticketIds: { id: string; status: Status }[] = [];
  for (const s of seeds) {
    const t = await rpc<{ id: string }>(page, "createTicket", {
      title: s.title,
      descriptionMd: s.desc,
      description: JSON.stringify({
        type: "doc",
        content: [{ type: "paragraph", content: [{ type: "text", text: s.desc }] }],
      }),
      repoId: s.repoId,
      status: s.status,
      priority: s.priority ?? 0,
      estimate: s.estimate ?? null,
      labelIds: s.labels ?? [],
    });
    if (s.labels && s.labels.length > 0) {
      await rpc(page, "setLabels", { ticketId: t.id, labelIds: s.labels });
    }
    ticketIds.push({ id: t.id, status: s.status });
  }

  // ─── Capture pass ────────────────────────────────────────────────────
  // 1680×900 fits all 5 board columns + sidebar comfortably. 24 frames
  // at ~8fps = a 3-second loop. The Water SVGs animate continuously
  // so the GIF is alive even between scripted card moves.
  await page.setViewportSize({ width: 1680, height: 900 });
  await page.goto("/");
  await page.waitForSelector("main", { timeout: 20_000 });
  await page.waitForTimeout(900);

  const fps = 8;
  const totalFrames = 24;
  const delayMs = Math.round(1000 / fps);

  // Pre-build the GIF encoder.
  const gif = GIFEncoder();
  let width = 0, height = 0;

  // A small script of status moves to keep cards visibly shuffling
  // during the recording window. We trigger one transition every few
  // frames; the rest is just the ambient wave/water motion.
  const moves: Array<{ atFrame: number; ticketIdx: number; to: Status }> = [
    { atFrame: 4,  ticketIdx: 5,  to: "in_progress" }, // AccessKit: queued → in_progress
    { atFrame: 10, ticketIdx: 7,  to: "review" },      // panic fix: in_progress → review
    { atFrame: 16, ticketIdx: 2,  to: "queued" },      // multicursor: backlog → queued
  ];

  for (let i = 0; i < totalFrames; i++) {
    // Apply any scheduled status change for this frame.
    const move = moves.find((m) => m.atFrame === i);
    if (move) {
      const target = ticketIds[move.ticketIdx];
      if (target) {
        await rpc(page, "setStatus", { ticketId: target.id, status: move.to }).catch(() => {});
      }
    }

    const png = PNG.sync.read(Buffer.from(await page.screenshot()));
    width = png.width;
    height = png.height;
    const rgba = new Uint8Array(png.data.buffer, png.data.byteOffset, png.data.byteLength);
    const palette = quantize(rgba, 256, { format: "rgba4444" });
    const index = applyPalette(rgba, palette, "rgba4444");
    gif.writeFrame(index, width, height, { palette, delay: delayMs });

    await page.waitForTimeout(delayMs);
  }
  gif.finish();

  const outPath = join(dirname(__thisFile), "..", "..", "landing", "demo.gif");
  mkdirSync(dirname(outPath), { recursive: true });
  writeFileSync(outPath, Buffer.from(gif.bytes()));
  // eslint-disable-next-line no-console
  console.log(`Wrote landing GIF: ${outPath} (${width}×${height}, ${totalFrames} frames @ ${fps}fps)`);
});
