/**
 * Water — the rising tide inside each Tideline column (handoff §Direction 2).
 *
 * Renders an absolutely-positioned layer at the bottom of its parent. The
 * water height is proportional to `level` (0..1, count / maxCount). On top
 * of the water sits a wavy surface made from two overlapping SVG sine
 * paths animating horizontally at slightly different speeds for parallax.
 *
 * Caller is expected to wrap this in a `position: relative; overflow:
 * hidden` container of any height. Water height uses a CSS calc() so it
 * works in fixed-height containers AND in flex-filled cylinders.
 */
export function Water({
  level,
  columnIndex = 0,
}: {
  level: number;
  columnIndex?: number;
}) {
  const clamped = Math.max(0, Math.min(1, level));
  // Water floor raised to 64px so the surface sits comfortably above the
  // "+ New ticket" affordance in the Triage column (~36px tall at the
  // bottom of the cylinder).
  const waterHeight = `calc(64px + ${clamped} * (100% - 100px))`;

  // Two wave layers with different speeds — adds depth via parallax.
  const baseSpeed = 6 + columnIndex;
  const slowSpeed = 10 + columnIndex * 0.5;

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-x-0 bottom-0 transition-[height] duration-500"
      style={{
        height: waterHeight,
        // OKLab gradient mixing var(--tide) + var(--tide-deep) per handoff,
        // with hard fallback for browsers without oklab support.
        background:
          "linear-gradient(180deg, color-mix(in oklab, hsl(var(--tide)) 18%, transparent), color-mix(in oklab, hsl(var(--tide-deep)) 12%, transparent))",
        transitionTimingFunction: "cubic-bezier(.4,.7,.2,1)",
      }}
    >
      {/* Wave surface — two overlapping sine paths animating horizontally. */}
      <svg
        className="absolute left-0 right-0 top-0 block w-[200%]"
        viewBox="0 0 400 12"
        preserveAspectRatio="none"
        style={{ height: 12, transform: "translateY(-6px)" }}
      >
        {/* Bottom wave: slower, mid-toned. */}
        <path
          d="M0 6 Q 25 0 50 6 T 100 6 T 150 6 T 200 6 T 250 6 T 300 6 T 350 6 T 400 6"
          fill="none"
          stroke="hsl(var(--tide))"
          strokeOpacity={0.6}
          strokeWidth={1.2}
          strokeLinecap="round"
          transform="translate(0,1.2)"
        >
          <animateTransform
            attributeName="transform"
            type="translate"
            from="0 1.2"
            to="-200 1.2"
            dur={`${slowSpeed}s`}
            repeatCount="indefinite"
          />
        </path>
        {/* Top wave: faster, ink-toned, slightly above. */}
        <path
          d="M0 6 Q 25 2 50 6 T 100 6 T 150 6 T 200 6 T 250 6 T 300 6 T 350 6 T 400 6"
          fill="none"
          stroke="hsl(var(--tide-deep))"
          strokeOpacity={0.5}
          strokeWidth={1.1}
          strokeLinecap="round"
        >
          <animateTransform
            attributeName="transform"
            type="translate"
            from="0 0"
            to="-200 0"
            dur={`${baseSpeed}s`}
            repeatCount="indefinite"
          />
        </path>
      </svg>
    </div>
  );
}

/**
 * Tiny horizontal water-level mini-bar — sits in the column header to give
 * a glanceable preview of the column's level even when scrolled past the
 * cylinder. ~32px wide, 4 segments shaded by level.
 */
export function WaterLevelMini({ level }: { level: number }) {
  const filled = Math.round(Math.max(0, Math.min(1, level)) * 4);
  return (
    <span
      aria-hidden="true"
      className="inline-flex items-end gap-[2px]"
      style={{ height: 8 }}
    >
      {[2, 4, 6, 8].map((h, i) => (
        <span
          key={i}
          style={{
            width: 4,
            height: h,
            background:
              i < filled ? "hsl(var(--tide))" : "rgba(0,0,0,0.08)",
            borderRadius: 1,
          }}
        />
      ))}
    </span>
  );
}
