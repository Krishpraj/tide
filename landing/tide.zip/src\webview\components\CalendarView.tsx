import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useStore, ticketInProject } from "../store";
import { useUiStore } from "../uistore";
import { StatusIcon } from "../lib/status";
import type { Ticket } from "@shared/types";

/**
 * Calendar view — tickets pinned to the day they were created (and snoozed
 * tickets at their wake-up date). A month grid, in the same paper aesthetic
 * as the rest of Tide. Click a ticket chip to open it.
 */
export function CalendarView() {
  const tickets = useStore((s) => s.tickets);
  const repos = useStore((s) => s.repos);
  const currentProjectId = useStore((s) => s.currentProjectId);
  const openTicket = useUiStore((s) => s.openTicket);

  const [cursor, setCursor] = useState(() => startOfMonth(new Date()));

  const scoped = useMemo(
    () => tickets.filter((t) => ticketInProject(t, repos, currentProjectId)),
    [tickets, repos, currentProjectId],
  );

  // Bucket tickets by yyyy-mm-dd.
  const byDay = useMemo(() => {
    const m = new Map<string, Ticket[]>();
    for (const t of scoped) {
      const d = t.snoozeUntil ?? t.createdAt;
      const key = dayKey(new Date(d));
      (m.get(key) ?? m.set(key, []).get(key))!.push(t);
    }
    return m;
  }, [scoped]);

  const monthName = cursor.toLocaleDateString(undefined, {
    month: "long",
    year: "numeric",
  });

  // Build a 6-row grid of dates including leading/trailing days for context.
  const cells = useMemo(() => {
    const first = new Date(cursor);
    first.setDate(1);
    const leading = first.getDay();
    const gridStart = new Date(first);
    gridStart.setDate(first.getDate() - leading);
    const out: Date[] = [];
    for (let i = 0; i < 42; i++) {
      const d = new Date(gridStart);
      d.setDate(gridStart.getDate() + i);
      out.push(d);
    }
    return out;
  }, [cursor]);

  function shift(months: number) {
    const d = new Date(cursor);
    d.setMonth(d.getMonth() + months);
    setCursor(startOfMonth(d));
  }

  const todayKey = dayKey(new Date());

  return (
    <div data-testid="calendar-view" className="flex-1 overflow-auto">
      <div className="mx-auto max-w-[1100px] px-6 py-5">
        <header className="mb-4 flex items-center gap-3">
          <span className="text-[13px] font-semibold text-tide-deep">
            Calendar
          </span>
          <div className="ml-auto inline-flex items-center gap-1 rounded-[9px] bg-card shadow-tide px-1 py-0.5">
            <button
              onClick={() => shift(-1)}
              aria-label="previous month"
              className="rounded p-1 text-tide-deep/55 hover:bg-black/[0.04] hover:text-tide-deep"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            <span className="px-2 text-[11.5px] font-medium text-tide-deep tabular-nums">
              {monthName}
            </span>
            <button
              onClick={() => shift(1)}
              aria-label="next month"
              className="rounded p-1 text-tide-deep/55 hover:bg-black/[0.04] hover:text-tide-deep"
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
          <button
            onClick={() => setCursor(startOfMonth(new Date()))}
            className="rounded-md border border-border bg-card px-2 py-1 text-[11px] text-tide-deep/65 hover:text-tide-deep hover:shadow-tide transition-shadow"
          >
            Today
          </button>
        </header>

        <div className="grid grid-cols-7 gap-px rounded-[12px] bg-tide-fog/40 overflow-hidden shadow-tide">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div
              key={d}
              className="bg-card px-2 py-1.5 text-[11px] font-semibold text-tide-deep/55"
            >
              {d}
            </div>
          ))}
          {cells.map((d) => {
            const inMonth = d.getMonth() === cursor.getMonth();
            const key = dayKey(d);
            const dayTickets = byDay.get(key) ?? [];
            const isToday = key === todayKey;
            return (
              <div
                key={key}
                className={
                  "min-h-[88px] bg-card p-1.5 " +
                  (inMonth ? "" : "opacity-50")
                }
              >
                <div className="flex items-baseline gap-1">
                  <span
                    className={
                      "text-[10.5px] tabular-nums " +
                      (isToday
                        ? "text-tide font-semibold"
                        : "text-tide-deep/65")
                    }
                  >
                    {d.getDate()}
                  </span>
                </div>
                <div className="mt-1 space-y-0.5">
                  {dayTickets.slice(0, 3).map((t) => (
                    <button
                      key={t.id}
                      onClick={() => openTicket(t.id)}
                      className="w-full flex items-center gap-1 rounded px-1 py-0.5 text-left text-[10px] text-tide-deep/85 hover:bg-black/[0.04]"
                      title={t.title}
                    >
                      <StatusIcon
                        status={t.status}
                        className="h-2.5 w-2.5 shrink-0"
                      />
                      <span className="truncate">{t.title}</span>
                    </button>
                  ))}
                  {dayTickets.length > 3 && (
                    <span className="px-1 text-[9px] text-tide-deep/45">
                      +{dayTickets.length - 3} more
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function startOfMonth(d: Date): Date {
  const x = new Date(d);
  x.setDate(1);
  x.setHours(0, 0, 0, 0);
  return x;
}

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
