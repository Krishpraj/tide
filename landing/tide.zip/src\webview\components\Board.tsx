import { useEffect, useMemo, useRef, useState } from "react";
import { rpc } from "../rpc";
import { useStore, ticketInProject } from "../store";
import {
  PRIORITY_LABELS,
  STATUS_COLUMNS,
  StatusIcon,
  statusLabel,
} from "../lib/status";
import { Badge } from "./ui/badge";
import { TicketCard } from "./TicketCard";
import { PromptHarness } from "./PromptHarness";
import { Plus } from "lucide-react";
import { Button } from "./ui/button";
import {
  BoardToolbar,
  type BoardFilters,
  type GroupBy,
  type SortBy,
} from "./BoardToolbar";
import { BulkActionBar } from "./BulkActionBar";
import { Water, WaterLevelMini } from "./Water";
import { useUiStore } from "../uistore";
import type { Priority, Ticket, TicketStatus } from "@shared/types";

const PRIORITY_GROUPS: Priority[] = [4, 3, 2, 1, 0];

export function Board() {
  const tickets = useStore((s) => s.tickets);
  const allRepos = useStore((s) => s.repos);
  const labels = useStore((s) => s.labels);
  const currentProjectId = useStore((s) => s.currentProjectId);
  const focusTicketComposerToken = useUiStore(
    (s) => s.focusTicketComposerToken,
  );
  // The legacy hotkey/menu fires this token to open the composer. Forward
  // it to the modal. Track the last-seen value with a ref so re-mounting
  // Board (e.g. after closing a review tab) doesn't replay an old token
  // and re-open the modal spuriously.
  const seenComposerToken = useRef(focusTicketComposerToken);
  useEffect(() => {
    if (focusTicketComposerToken > seenComposerToken.current) {
      seenComposerToken.current = focusTicketComposerToken;
      setNewOpen(true);
    }
  }, [focusTicketComposerToken]);
  const selected = useUiStore((s) => s.selectedTickets);
  const setSelected = useUiStore((s) => s.setSelectedTickets);
  const sidebarFilter = useUiStore((s) => s.sidebarFilter);

  const [groupBy, setGroupBy] = useState<GroupBy>("status");
  const [sortBy, setSortBy] = useState<SortBy>("priority");
  const [filters, setFilters] = useState<BoardFilters>({});
  const [newOpen, setNewOpen] = useState(false);
  const [newSubmitting, setNewSubmitting] = useState(false);

  // Scope the repo list shown in toolbar/grouping to the current project.
  const repos = useMemo(
    () =>
      currentProjectId
        ? allRepos.filter((r) => r.projectId === currentProjectId)
        : allRepos,
    [allRepos, currentProjectId],
  );

  const filtered = useMemo(() => {
    return tickets.filter((t) => {
      if (!ticketInProject(t, allRepos, currentProjectId)) return false;
      if (
        sidebarFilter === "recently_closed" &&
        t.status !== "done" &&
        t.status !== "discarded"
      )
        return false;
      if (filters.status && t.status !== filters.status) return false;
      if (
        filters.priority !== undefined &&
        filters.priority !== null &&
        t.priority !== filters.priority
      )
        return false;
      if (filters.repoId && t.repoId !== filters.repoId) return false;
      if (
        filters.labelId &&
        !t.labels?.some((l) => l.id === filters.labelId)
      )
        return false;
      return true;
    });
  }, [tickets, filters, allRepos, currentProjectId, sidebarFilter]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    arr.sort((a, b) => {
      switch (sortBy) {
        case "priority":
          if (a.priority !== b.priority) return b.priority - a.priority;
          return a.createdAt - b.createdAt;
        case "created":
          return b.createdAt - a.createdAt;
        case "updated":
          return b.updatedAt - a.updatedAt;
        case "estimate": {
          const order = { XS: 1, S: 2, M: 3, L: 4, XL: 5 } as Record<
            string,
            number
          >;
          return (order[a.estimate ?? ""] ?? 0) - (order[b.estimate ?? ""] ?? 0);
        }
      }
    });
    return arr;
  }, [filtered, sortBy]);

  const groups = useMemo(() => buildGroups(sorted, groupBy, repos, labels), [
    sorted,
    groupBy,
    repos,
    labels,
  ]);

  function onCardClick(id: string, e: React.MouseEvent) {
    if (e.shiftKey) {
      setSelected(
        selected.includes(id)
          ? selected.filter((x) => x !== id)
          : [...selected, id],
      );
    }
  }

  async function onDrop(targetStatus: TicketStatus, e: React.DragEvent) {
    e.preventDefault();
    const id = e.dataTransfer.getData("text/x-tide-ticket");
    if (!id) return;
    const t = tickets.find((x) => x.id === id);
    if (!t || t.status === targetStatus) return;
    await rpc.setStatus({ ticketId: id, status: targetStatus });
  }

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <BoardToolbar
        groupBy={groupBy}
        sortBy={sortBy}
        filters={filters}
        onGroup={setGroupBy}
        onSort={setSortBy}
        onFilter={setFilters}
      />

      <div className="flex-1 min-h-0 overflow-x-auto overflow-y-hidden">
        <div className="h-full pt-[18px] px-[22px] pb-[22px] min-w-max flex flex-col">
          <div
            data-testid="board"
            data-group-by={groupBy}
            className="grid gap-[14px] flex-1 min-h-0"
            style={{
              gridTemplateColumns: `repeat(${groups.length}, minmax(220px, 1fr))`,
            }}
          >
            {groups.map((group, ci) => {
              const maxCount = Math.max(
                1,
                ...groups.map((g) => g.tickets.length),
              );
              const level = group.tickets.length / maxCount;
              return (
                <div
                  key={group.key}
                  data-testid={`column-${group.key}`}
                  className="flex min-w-0 flex-col min-h-0"
                >
                  <div className="flex items-center gap-2 px-0.5 pb-[10px]">
                    {group.icon}
                    <span
                      data-testid={`column-${group.key}-label`}
                      className="text-[12.5px] font-semibold text-tide-deep"
                    >
                      {group.label}
                    </span>
                    <span
                      data-testid={`column-${group.key}-count`}
                      className="font-mono text-[11px] text-tide-deep/40 tabular-nums"
                    >
                      {group.tickets.length}
                    </span>
                    {groupBy === "status" && <WaterLevelMini level={level} />}
                    {group.key === "triage" && (
                      <button
                        onClick={() => setNewOpen(true)}
                        aria-label="new ticket"
                        className="ml-auto inline-flex h-5 w-5 items-center justify-center rounded text-tide-deep/55 hover:bg-black/[0.04] hover:text-tide-deep"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                  {/* Glass cylinder — fills the remaining vertical space,
                      water rises at bottom, cards anchor at the bottom and
                      stack upward (above the water). */}
                  <div
                    onDragOver={(e) => {
                      if (groupBy === "status") e.preventDefault();
                    }}
                    onDrop={(e) =>
                      groupBy === "status" &&
                      onDrop(group.key as TicketStatus, e)
                    }
                    className="relative flex-1 min-h-0 overflow-hidden rounded-[14px] border border-black/[0.05] bg-black/[0.015]"
                  >
                    {/* Water backdrop — only meaningful when grouped by status. */}
                    {groupBy === "status" && (
                      <Water level={level} columnIndex={ci} />
                    )}
                    {/* Cards (and Triage's "+ New ticket" affordance)
                        anchor to the BOTTOM of the cylinder and stack
                        upward. flex-col-reverse with the New-ticket
                        button rendered FIRST puts it at the deepest
                        (visual-bottom) position; cards stack above it. */}
                    <div className="relative z-10 h-full overflow-y-auto p-[10px] flex flex-col-reverse gap-2 [scrollbar-width:thin]">
                      {group.key === "triage" && (
                        <button
                          data-testid="board-new-ticket"
                          onClick={() => setNewOpen(true)}
                          className="flex items-center gap-2 rounded-[10px] border border-dashed border-tide-deep/[0.18] bg-white/85 backdrop-blur-[2px] px-3 py-2.5 text-[13px] text-tide-deep/70 hover:border-tide-deep/40 hover:text-tide-deep transition-colors shrink-0"
                        >
                          <Plus className="h-3.5 w-3.5" />
                          <span className="flex-1 text-left">New ticket</span>
                          <kbd className="font-mono text-[10.5px] text-tide-deep/40 bg-black/[0.04] rounded px-1.5 py-0.5">
                            C
                          </kbd>
                        </button>
                      )}
                      {group.tickets.map((t) => (
                        <TicketCard
                          key={t.id}
                          ticket={t}
                          selected={selected.includes(t.id)}
                          onSelectClick={(e) => onCardClick(t.id, e)}
                          onOpen={(id) => useUiStore.getState().openTicket(id)}
                          showStatusIcon={groupBy !== "status"}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <BulkActionBar
        selected={selected}
        onClear={() => setSelected([])}
      />

      <PromptHarness
        open={newOpen}
        onOpenChange={setNewOpen}
        mode="new"
        submitting={newSubmitting}
        onSubmit={async ({ title, docJson, markdown, repoId: r, planMode }) => {
          setNewSubmitting(true);
          try {
            await rpc.createTicket({
              title,
              description: JSON.stringify(docJson),
              descriptionMd: markdown,
              repoId: r,
              planMode,
            });
          } finally {
            setNewSubmitting(false);
            setNewOpen(false);
          }
        }}
      />
    </div>
  );
}

interface Group {
  key: string;
  label: string;
  icon: React.ReactNode;
  tickets: Ticket[];
}

function buildGroups(
  tickets: Ticket[],
  groupBy: GroupBy,
  repos: { id: string; name: string }[],
  labels: { id: string; name: string; color: string }[],
): Group[] {
  if (groupBy === "status") {
    return STATUS_COLUMNS.map((s) => ({
      key: s,
      label: statusLabel(s),
      icon: <StatusIcon status={s} />,
      tickets: tickets.filter((t) => t.status === s),
    }));
  }
  if (groupBy === "priority") {
    return PRIORITY_GROUPS.map((p) => ({
      key: `priority-${p}`,
      label: PRIORITY_LABELS[p],
      icon: null,
      tickets: tickets.filter((t) => t.priority === p),
    }));
  }
  if (groupBy === "repo") {
    const out: Group[] = [
      {
        key: "no-repo",
        label: "No repo",
        icon: null,
        tickets: tickets.filter((t) => !t.repoId),
      },
    ];
    for (const r of repos) {
      out.push({
        key: `repo-${r.name}`,
        label: r.name,
        icon: null,
        tickets: tickets.filter((t) => t.repoId === r.id),
      });
    }
    return out;
  }
  if (groupBy === "label") {
    const out: Group[] = [
      {
        key: "no-label",
        label: "No label",
        icon: null,
        tickets: tickets.filter((t) => !t.labels || t.labels.length === 0),
      },
    ];
    for (const l of labels) {
      out.push({
        key: `label-${l.name}`,
        label: l.name,
        icon: (
          <span
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: l.color }}
          />
        ),
        tickets: tickets.filter((t) => t.labels?.some((x) => x.id === l.id)),
      });
    }
    return out;
  }
  // none
  return [
    {
      key: "all",
      label: "All tickets",
      icon: null,
      tickets,
    },
  ];
}

