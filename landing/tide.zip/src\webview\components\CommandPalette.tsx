import { Command } from "cmdk";
import { Search } from "lucide-react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { useUiStore } from "../uistore";
import { useStore } from "../store";
import { rpc } from "../rpc";
import { useEffect, useState } from "react";
import { StatusIcon } from "../lib/status";

export function CommandPalette() {
  const open = useUiStore((s) => s.commandOpen);
  const setOpen = useUiStore((s) => s.setCommandOpen);
  const triggerComposer = useUiStore((s) => s.triggerFocusComposer);
  const setCs = useUiStore((s) => s.setCheatsheetOpen);
  const toggleTheme = useUiStore((s) => s.toggleTheme);
  const setFv = useUiStore((s) => s.setFocusViewOpen);
  const setQs = useUiStore((s) => s.setQuickSwitcherOpen);

  const projects = useStore((s) => s.projects);
  const repos = useStore((s) => s.repos);
  const tickets = useStore((s) => s.tickets);
  const setProject = useStore((s) => s.setCurrentProject);

  const [views, setViews] = useState<{ id: string; name: string }[]>([]);
  useEffect(() => {
    if (open) {
      rpc.listSavedViews().then(setViews).catch(() => setViews([]));
    }
  }, [open]);

  function close() {
    setOpen(false);
  }

  return (
    <DialogPrimitive.Root open={open} onOpenChange={setOpen}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/[0.18] backdrop-blur-[2px] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
        <DialogPrimitive.Content
          data-testid="command-palette"
          className="fixed left-1/2 top-[15%] z-50 w-[min(540px,92vw)] -translate-x-1/2 rounded-[12px] bg-card shadow-palette overflow-hidden tide-palette-rise"
        >
          <DialogPrimitive.Title className="sr-only">
            Command Palette
          </DialogPrimitive.Title>
          <Command
            className="bg-transparent"
            filter={(value, search) => {
              const v = value.toLowerCase();
              const s = search.toLowerCase().trim();
              if (!s) return 1;
              return v.includes(s) ? 1 : 0;
            }}
          >
            <div className="flex items-center gap-2 border-b border-black/[0.06] px-4 h-12">
              <Search className="h-4 w-4 text-tide-deep/45 shrink-0" />
              <Command.Input
                placeholder="Search or jump to…"
                className="flex-1 bg-transparent border-0 text-[14px] text-tide-deep placeholder:text-tide-deep/40 focus:outline-none"
                data-testid="command-input"
              />
              <kbd className="font-mono inline-flex items-center rounded bg-white px-1.5 py-[2px] text-[10.5px] text-tide-deep/55 border border-black/[0.08]">
                Esc
              </kbd>
            </div>
            <Command.List className="max-h-[420px] overflow-y-auto p-1.5">
              <Command.Empty className="px-3 py-10 text-center text-[12px] text-tide-deep/45 italic">
                No matching commands or tickets.
              </Command.Empty>

              <CmdGroup heading="Actions">
                <CmdItem
                  onSelect={() => {
                    triggerComposer();
                    close();
                  }}
                  testid="cmd-new-ticket"
                  trailing="C"
                >
                  New ticket
                </CmdItem>
                <CmdItem
                  onSelect={() => {
                    setFv(true);
                    close();
                  }}
                  testid="cmd-focus-view"
                  trailing="F"
                >
                  Toggle focus mode
                </CmdItem>
                <CmdItem
                  onSelect={() => {
                    setQs(true);
                    close();
                  }}
                  testid="cmd-quick-switcher"
                  trailing="⌘P"
                >
                  Jump to ticket…
                </CmdItem>
                <CmdItem
                  onSelect={() => {
                    toggleTheme();
                    close();
                  }}
                  testid="cmd-toggle-theme"
                  trailing="T"
                >
                  Toggle theme
                </CmdItem>
                <CmdItem
                  onSelect={() => {
                    setCs(true);
                    close();
                  }}
                  testid="cmd-shortcuts"
                  trailing="?"
                >
                  Keyboard shortcuts
                </CmdItem>
              </CmdGroup>

              <CmdGroup heading="Tickets">
                {tickets.map((t) => (
                  <Command.Item
                    key={t.id}
                    value={`${t.title} TID-${t.id.slice(-4)}`}
                    onSelect={() => {
                      useUiStore.getState().openTicket(t.id);
                      close();
                    }}
                    data-testid={`cmd-ticket-${t.title.replace(/\s+/g, "-")}`}
                    className="group flex items-center gap-2.5 rounded-[7px] px-2 py-1.5 text-[12.5px] cursor-pointer data-[selected=true]:bg-tide-deep/[0.07]"
                  >
                    <StatusIcon status={t.status} className="h-3.5 w-3.5 shrink-0" />
                    <span className="font-mono text-[10.5px] text-tide-deep/45 w-[58px] shrink-0">
                      TID-{t.id.slice(-4).toUpperCase()}
                    </span>
                    <span className="flex-1 truncate text-tide-deep">
                      {t.title}
                    </span>
                  </Command.Item>
                ))}
              </CmdGroup>

              <CmdGroup heading="Projects">
                {projects.map((p) => (
                  <CmdItem
                    key={p.id}
                    onSelect={() => {
                      setProject(p.id);
                      close();
                    }}
                    testid={`cmd-project-${p.name}`}
                  >
                    Switch to {p.name}
                  </CmdItem>
                ))}
              </CmdGroup>

              {repos.length > 0 && (
                <CmdGroup heading="Repos">
                  {repos.map((r) => (
                    <CmdItem
                      key={r.id}
                      onSelect={() => close()}
                      testid={`cmd-repo-${r.name}`}
                    >
                      Open repo {r.name}
                    </CmdItem>
                  ))}
                </CmdGroup>
              )}

              {views.length > 0 && (
                <CmdGroup heading="Views">
                  {views.map((v) => (
                    <CmdItem
                      key={v.id}
                      onSelect={() => close()}
                      testid={`cmd-view-${v.name.replace(/\s+/g, "-")}`}
                    >
                      {v.name}
                    </CmdItem>
                  ))}
                </CmdGroup>
              )}
            </Command.List>
            <div className="flex items-center justify-between border-t border-black/[0.06] px-4 py-2 font-mono text-[10px] text-tide-deep/45">
              <span>↑↓ navigate · ↵ open</span>
              <span>Tide command palette</span>
            </div>
          </Command>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

function CmdGroup({
  heading,
  children,
}: {
  heading: string;
  children: React.ReactNode;
}) {
  return (
    <Command.Group
      heading={heading}
      className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:pt-2 [&_[cmdk-group-heading]]:pb-1 [&_[cmdk-group-heading]]:text-[11px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:text-tide-deep/55"
    >
      {children}
    </Command.Group>
  );
}

function CmdItem({
  children,
  onSelect,
  testid,
  trailing,
}: {
  children: React.ReactNode;
  onSelect: () => void;
  testid?: string;
  trailing?: string;
}) {
  return (
    <Command.Item
      onSelect={onSelect}
      data-testid={testid}
      className="group flex items-center gap-2 rounded-[7px] px-2 py-1.5 text-[12.5px] text-tide-deep cursor-pointer data-[selected=true]:bg-tide-deep/[0.07]"
    >
      {children}
      {trailing && (
        <kbd className="ml-auto font-mono text-[10px] text-tide-deep/45 bg-black/[0.04] rounded px-1 py-px">
          {trailing}
        </kbd>
      )}
    </Command.Item>
  );
}
