import { useEffect, useMemo, useState } from "react";
import {
  Ban,
  ChevronDown,
  ExternalLink,
  GitMerge,
  GitPullRequest,
  RefreshCw,
  Trash2,
} from "lucide-react";
import { rpc } from "../rpc";
import { useStore } from "../store";
import { useUiStore } from "../uistore";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { ScrollArea } from "./ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { PromptHarness } from "./PromptHarness";
import { DiffView } from "./DiffView";
import { LiveStream } from "./LiveStream";
import { CommentsPanel } from "./CommentsPanel";
import { TicketEditor } from "./editor/TicketEditor";
import { StatusIcon, statusLabel } from "../lib/status";
import type { Editor, Ticket, TicketEvent } from "@shared/types";

export function ReviewPanel({ ticketId }: { ticketId: string }) {
  const ticket = useStore((s) => s.tickets.find((t) => t.id === ticketId));
  const repos = useStore((s) => s.repos);
  const repo = ticket?.repoId
    ? repos.find((r) => r.id === ticket.repoId) ?? null
    : null;
  const openTicket = useUiStore((s) => s.openTicket);

  const [diff, setDiff] = useState("");
  const [events, setEvents] = useState<TicketEvent[]>([]);
  const [editors, setEditors] = useState<
    { id: string; label: string; command: string }[]
  >([]);
  const [changeMoreOpen, setChangeMoreOpen] = useState(false);
  const [changeMoreSubmitting, setChangeMoreSubmitting] = useState(false);
  const [commitOpen, setCommitOpen] = useState(false);
  const [commitMessage, setCommitMessage] = useState("");

  useEffect(() => {
    void rpc.getDiff(ticketId).then(setDiff);
    void rpc.getTicketEvents(ticketId).then((es) => setEvents(es));
    void rpc.listEditors().then(setEditors);
    const off = rpc.on("claudeMessage", (m) => {
      if (m.ticketId === ticketId) {
        void rpc.getTicketEvents(ticketId).then((es) => setEvents(es));
        void rpc.getDiff(ticketId).then(setDiff);
      }
    });
    return off;
  }, [ticketId]);

  if (!ticket) {
    return (
      <div className="p-6 text-sm text-muted-foreground">
        Ticket not found.
      </div>
    );
  }

  async function onMerge(strategy: "merge" | "squash") {
    await rpc.mergeTicket({ ticketId, strategy });
    openTicket(null);
  }

  async function onDiscard() {
    await rpc.discardTicket(ticketId);
    openTicket(null);
  }

  async function onCancel() {
    await rpc.cancelTicket(ticketId);
  }

  async function onChangeMore(md: string) {
    if (!md.trim()) return;
    await rpc.iterateTicket({
      ticketId,
      instructions: md,
      instructionsMd: md,
    });
    setChangeMoreOpen(false);
  }

  async function onRefresh() {
    setDiff(await rpc.refreshDiff(ticketId));
    setEvents(await rpc.getTicketEvents(ticketId));
  }

  async function onCommitEdits() {
    if (!commitMessage.trim()) return;
    const r = await rpc.commitLocalEdits({
      ticketId,
      message: commitMessage.trim(),
    });
    setCommitOpen(false);
    setCommitMessage("");
    if (r.committed) await onRefresh();
  }

  async function onOpenInEditor(editorId: string) {
    await rpc.openInEditor({ ticketId, editorId });
  }

  const isInProgress = ticket.status === "in_progress";

  const shortId = `TID-${ticket.id.slice(-4).toUpperCase()}`;

  return (
    <div
      data-testid="review-panel"
      className="flex-1 flex flex-col min-h-0 min-w-0"
    >
      {/* Header — ID + status + plan + branch */}
      <div className="flex items-center gap-2 pl-5 pr-11 pt-4 pb-3">
        <span className="font-mono text-[11px] text-tide-deep/45 tabular-nums">
          {shortId}
        </span>
        <StatusIcon status={ticket.status} />
        <span className="text-[11px] text-tide-deep/55">
          {statusLabel(ticket.status)}
        </span>
        {ticket.planMode && (
          <span className="text-[10px] text-tide-sand">plan</span>
        )}
        {ticket.branchName && (
          <code className="font-mono text-[10px] text-tide-deep/45 truncate max-w-[140px]">
            {ticket.branchName}
          </code>
        )}
      </div>

      {/* Title */}
      <div className="px-5 pb-3">
        <h1 className="text-[19px] font-semibold leading-[1.3] text-tide-deep">
          {ticket.title}
        </h1>
        {repo && (
          <div className="mt-2 font-mono text-[11px] text-tide-deep/55">
            {repo.name}
          </div>
        )}
      </div>

      {/* Action bar */}
      <div className="flex flex-wrap items-center gap-1.5 border-t border-b border-black/[0.05] px-5 py-2.5">
        <CodeButton
          editors={editors}
          onSelect={onOpenInEditor}
          inProgress={isInProgress}
        />
        {isInProgress ? (
          <Button
            size="sm"
            variant="destructive"
            data-testid="review-cancel"
            onClick={onCancel}
          >
            <Ban className="h-3.5 w-3.5" /> Cancel
          </Button>
        ) : (
          <>
            <Button
              size="sm"
              variant="ghost"
              data-testid="review-refresh"
              onClick={onRefresh}
              className="h-7 px-2"
            >
              <RefreshCw className="h-3 w-3" /> Refresh
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  size="sm"
                  data-testid="review-merge"
                  className="h-7 px-2.5"
                >
                  <GitMerge className="h-3 w-3" /> Merge
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onSelect={() => onMerge("merge")}
                  data-testid="review-merge-merge"
                >
                  Merge
                </DropdownMenuItem>
                <DropdownMenuItem
                  onSelect={() => onMerge("squash")}
                  data-testid="review-merge-squash"
                >
                  Squash & merge
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              size="sm"
              variant="outline"
              data-testid="review-change-more"
              onClick={() => setChangeMoreOpen(true)}
              className="h-7 px-2"
            >
              <GitPullRequest className="h-3 w-3" /> Change more
            </Button>
            <Button
              size="sm"
              variant="ghost"
              data-testid="review-commit-edits"
              onClick={() => setCommitOpen(true)}
              className="h-7 px-2"
            >
              Commit edits
            </Button>
            <Button
              size="sm"
              variant="ghost"
              data-testid="review-discard"
              onClick={onDiscard}
              className="h-7 px-2 text-destructive hover:text-destructive"
            >
              <Trash2 className="h-3 w-3" /> Discard
            </Button>
          </>
        )}
      </div>

      {/* Main content — vertical stack (panel is 440px wide) */}
      <div className="flex flex-1 min-h-0 flex-col">
        <ScrollArea className="flex-1">
          <div className="px-5 py-4">
            {isInProgress ? (
              <LiveStream ticketId={ticketId} />
            ) : diff.trim() ? (
              <DiffView unifiedDiff={diff} />
            ) : (
              <DescriptionPane ticket={ticket} events={events} />
            )}
          </div>

          <div className="border-t border-black/[0.05] px-5 py-4 space-y-2">
            <div className="text-[11px] font-semibold text-tide-deep/55">
              Activity
            </div>
            {events.length === 0 && (
              <p className="text-[11.5px] text-tide-deep/40 italic">
                No activity yet.
              </p>
            )}
            {events.map((e) => (
              <ActivityRow key={e.id} event={e} />
            ))}
          </div>

          <div className="border-t border-black/[0.05] px-5 py-4">
            <CommentsPanel ticketId={ticketId} />
          </div>
        </ScrollArea>
      </div>

      {/* Change more */}
      <PromptHarness
        open={changeMoreOpen}
        onOpenChange={setChangeMoreOpen}
        mode="iterate"
        initialRepoId={ticket.repoId}
        ticketId={ticket.id}
        submitting={changeMoreSubmitting}
        onSubmit={async ({ markdown }) => {
          setChangeMoreSubmitting(true);
          try {
            await onChangeMore(markdown);
          } finally {
            setChangeMoreSubmitting(false);
          }
        }}
      />

      {/* Commit my edits */}
      <Dialog open={commitOpen} onOpenChange={setCommitOpen}>
        <DialogContent data-testid="commit-edits-dialog">
          <DialogHeader>
            <DialogTitle>Commit local edits</DialogTitle>
          </DialogHeader>
          <input
            data-testid="commit-edits-message"
            placeholder="manual tweak"
            value={commitMessage}
            onChange={(e) => setCommitMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") onCommitEdits();
            }}
            className="w-full bg-transparent border border-input rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-ring"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setCommitOpen(false)}>
              Cancel
            </Button>
            <Button
              data-testid="commit-edits-submit"
              onClick={onCommitEdits}
              disabled={!commitMessage.trim()}
            >
              Commit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CodeButton({
  editors,
  onSelect,
  inProgress,
}: {
  editors: Editor[];
  onSelect: (id: string) => void;
  inProgress: boolean;
}) {
  if (editors.length === 0) {
    return (
      <Button
        size="sm"
        variant="outline"
        disabled
        data-testid="review-code-disabled"
        title="No editor detected on PATH"
      >
        <ExternalLink className="h-3.5 w-3.5" /> Code
      </Button>
    );
  }
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          size="sm"
          variant="outline"
          data-testid="review-code"
          title={
            inProgress
              ? "Claude is editing — your changes may be overwritten"
              : "Open in your editor"
          }
        >
          <ExternalLink className="h-3.5 w-3.5" /> Code
          {inProgress && (
            <span className="ml-1 text-[10px] text-tide-sand">live</span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {editors.map((e) => (
          <DropdownMenuItem
            key={e.id}
            onSelect={() => onSelect(e.id)}
            data-testid={`code-editor-${e.id}`}
          >
            {e.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function ActivityRow({ event }: { event: TicketEvent }) {
  const payload = event.payload as { name?: string; message?: string } | null;
  const summary = (() => {
    switch (event.kind) {
      case "status_change":
        return `→ ${(payload as { status?: string })?.status ?? "?"}`;
      case "tool_use":
        return `tool: ${payload?.name ?? "?"}`;
      case "merged":
        return "merged into base";
      case "iterate":
        return "iterate requested";
      case "canceled":
        return "canceled";
      case "discarded":
        return "discarded";
      case "manual_commit":
        return "manual commit";
      case "editor_opened":
        return "editor opened";
      case "error":
        return `error: ${(payload as { message?: string })?.message ?? ""}`;
      default:
        return event.kind;
    }
  })();
  return (
    <div className="text-xs text-muted-foreground">
      <span className="opacity-50 font-mono mr-2">
        {new Date(event.ts).toLocaleTimeString()}
      </span>
      {summary}
    </div>
  );
}

/**
 * The "no diff yet" main pane — shows the ticket's description rendered
 * read-only. Plan-mode tickets see their refined content here. Re-renders
 * when ticket.description changes (the refiner emits ticketUpdated when
 * it writes back, and Zustand wakes us up).
 *
 * For orphan tickets that ran through the worker before the refiner
 * existed (or any non-plan ticket whose run produced text but no diff),
 * surface Claude's last `result` message in a banner above the
 * description so the user isn't left with an empty pane.
 */
function DescriptionPane({
  ticket,
  events,
}: {
  ticket: Ticket;
  events: TicketEvent[];
}) {
  // Parse the stored TipTap JSON. Fall back to a single-paragraph doc
  // built from descriptionMd if parsing fails or the JSON doc is empty.
  const doc = useMemo(() => {
    if (ticket.description) {
      try {
        const parsed = JSON.parse(ticket.description);
        if (parsed && typeof parsed === "object" && parsed.type === "doc") {
          return parsed;
        }
      } catch {
        /* fall through */
      }
    }
    if (ticket.descriptionMd) {
      return {
        type: "doc",
        content: [
          {
            type: "paragraph",
            content: [{ type: "text", text: ticket.descriptionMd }],
          },
        ],
      };
    }
    return { type: "doc", content: [] };
  }, [ticket.description, ticket.descriptionMd]);

  const empty =
    !ticket.descriptionMd?.trim() &&
    (!ticket.description ||
      ticket.description === "{}" ||
      ticket.description === '{"type":"doc","content":[]}');

  // Walk the event log for the last Claude `result` message (or stage
  // event that carries a result-like payload). For orphan plan tickets
  // that ran through the old worker path, this is the only place the
  // user can see what Claude actually said.
  const lastResult = useMemo(() => {
    for (let i = events.length - 1; i >= 0; i--) {
      const e = events[i]!;
      if (e.kind !== "claude_message") continue;
      const p = e.payload as
        | { type?: string; result?: string }
        | null
        | undefined;
      if (p && p.type === "result" && typeof p.result === "string") {
        return { text: p.result, ts: e.ts };
      }
    }
    return null;
  }, [events]);

  return (
    <div className="mx-auto max-w-[820px] px-8 py-6 space-y-5">
      {lastResult && (
        <div>
          <div className="mb-2 flex items-center gap-2">
            <span className="text-[11px] font-semibold text-tide">
              Last result from Claude
            </span>
            <span className="text-[10px] text-tide-deep/40 tabular-nums">
              {new Date(lastResult.ts).toLocaleString()}
            </span>
          </div>
          <pre
            data-testid="last-result"
            className="rounded-[12px] bg-card shadow-tide px-5 py-4 text-[12.5px] leading-relaxed text-tide-deep whitespace-pre-wrap font-sans"
          >
            {lastResult.text}
          </pre>
        </div>
      )}

      <div>
        <div className="mb-4 flex items-center gap-2">
          <span className="text-[11px] font-semibold text-tide-deep/55">
            Description
          </span>
          {ticket.planMode && (
            <span className="text-[10px] text-tide-sand">plan</span>
          )}
        </div>
        {empty ? (
          <p className="text-[12.5px] text-tide-deep/45 italic">
            {ticket.planMode
              ? "Claude is refining this ticket — content will appear here when ready."
              : "No description."}
          </p>
        ) : (
          <div className="rounded-[12px] bg-card shadow-tide px-5 py-4">
            <TicketEditor
              // Forcing remount on doc change ensures TipTap rehydrates
              // cleanly when the refiner writes new content while the
              // user has the ticket open.
              key={JSON.stringify(doc).length + ":" + ticket.updatedAt}
              initial={doc}
              editable={false}
              className="prose prose-sm max-w-none"
            />
          </div>
        )}
      </div>
    </div>
  );
}
