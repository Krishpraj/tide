import type { Config } from "tailwindcss";
import animate from "tailwindcss-animate";

export default {
  darkMode: ["class"],
  content: ["./src/webview/**/*.{ts,tsx,html}"],
  theme: {
    container: {
      center: true,
      padding: "1rem",
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        priority: {
          urgent: "hsl(0 60% 50%)",
          high: "hsl(28 70% 52%)",
          medium: "hsl(38 70% 52%)",
          low: "hsl(194 30% 42%)",
          none: "hsl(215 8% 56%)",
        },
        // Tide palette (Tideline default — exact hex values from the
        // design handoff). Use `bg-tide`, `text-tide-deep`, `bg-tide-soft`,
        // etc. CSS vars allow runtime palette swaps later.
        tide: {
          DEFAULT: "hsl(var(--tide))",   // #4a7c8a mid
          deep: "hsl(var(--tide-deep))", // #1a3a4a ink
          fog: "hsl(var(--tide-fog))",   // #c8d4d6 soft
          sand: "hsl(var(--tide-sand))", // #c89b6a
          sea: "hsl(var(--tide-sea))",   // #6aa890
        },
        // Per-status tones — used for status icons, card halos when
        // dragging, atlas legend pills.
        statust: {
          triage: "#b88a8a",
          backlog: "#9aa4a8",
          queued: "#7aa8b8",
          progress: "#c89b6a",
          review: "#a890b8",
          done: "#6aa890",
        },
        // Per-label tones — match the design's muted-pastel scheme.
        labelt: {
          design: "#7aa8b8",
          eng: "#8aa890",
          bug: "#b88a8a",
          perf: "#c89b6a",
          ml: "#a890b8",
          product: "#6a9bc8",
          content: "#a8a890",
        },
      },
      boxShadow: {
        // Card resting / hover / dragging (per handoff §Shadows)
        "card-rest": "0 1px 0 rgba(0,0,0,.02)",
        "card-hover":
          "0 2px 6px rgba(0,0,0,.06), 0 0 0 1px rgba(0,0,0,.06)",
        "card-drag": "0 8px 24px rgba(0,0,0,.12)",
        // Tideline floating glass card
        "card-float":
          "inset 0 1px 0 rgba(255,255,255,.5), 0 2px 6px rgba(20,40,60,.07), 0 0 0 1px rgba(0,0,0,.04)",
        // Detail panel (slide-in from right)
        "panel-detail": "-8px 0 32px rgba(0,0,0,.08)",
        // ⌘K palette
        "palette":
          "0 24px 80px rgba(0,0,0,.22), 0 0 0 1px rgba(0,0,0,.06)",
        // Segmented top-nav active item
        "seg-active":
          "0 1px 2px rgba(0,0,0,.06), 0 0 0 1px rgba(0,0,0,.04)",
        // Legacy tokens (kept for transition, will retire)
        tide: "var(--shadow-tide)",
        "tide-lift": "var(--shadow-tide-lift)",
      },
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "sans-serif",
        ],
        // JetBrains Mono for IDs, dates, kbd, microlabels — per handoff.
        mono: [
          "JetBrains Mono",
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "Monaco",
          "Consolas",
          "monospace",
        ],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      letterSpacing: {
        tight: "-0.01em",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [animate],
} satisfies Config;
