import { useMemo } from "react";
import { useStore, ticketInProject } from "./../store";
import { useUiStore } from "./../uistore";
import { StatusIcon, statusLabel } from "../lib/status";
import { PriorityIcon } from "../lib/status";
import type { Ticket } from "@shared/types";

/**
 * Linear-style flat list view. Same data as the board, but rendered as
 * grouped rows with a single line per ticket. Honors the sidebar filter
 * (mine / subscribed / recently closed). Status icon · ID · title · repo
 * · labels · estimate · updated, on one row.
 */
export function ListView() {
  const tickets = useStore((s) => s.tickets);
  const repos = useStore((s) => s.repos);
  const currentProjectId = useStore((s) => s.currentProjectId);
  const openTicket = useUiStore((s) => s.openTicket);
  const filter = useUiStore((s) => s.sidebarFilter);

  const scoped = useMemo(() => {
    let arr = tickets.filter((t) =>
      ticketInProject(t, repos, currentProjectId),
    );
    if (filter === "recently_closed") {
      arr = arr
        .filter((t) => t.status === "done" || t.status === "discarded")
        .sort((a, b) => b.updatedAt - a.updatedAt)
        .slice(0, 50);
    }
    return arr;
  }, [tickets, repos, currentProjectId, filter]);

  // Group by status in the canonical order.
  const groups = useMemo(() => {
    const order: Ticket["status"][] = [
      "triage",
      "backlog",
      "queued",
      "in_progress",
      "review",
      "done",
      "discarded",
      "canceled",
      "failed",
      "snoozed",
    ];
    return order
      .map((s) => ({
        status: s,
        tickets: scoped.filter((t) => t.status === s),
      }))
      .filter((g) => g.tickets.length > 0);
  }, [scoped]);

  return (
    <div data-testid="list-view" className="flex-1 overflow-auto">
      <div className="mx-auto max-w-[1100px] px-6 py-5">
        {groups.length === 0 && (
          <p className="px-2 py-12 text-center text-[12px] text-tide-deep/45 italic">
            Calm waters — no tickets match.
          </p>
        )}
        {groups.map((g) => (
          <section key={g.status} className="mb-5">
            <header className="mb-1.5 flex items-center gap-2 px-1">
              <StatusIcon status={g.status} className="h-3 w-3" />
              <span className="text-[12px] font-semibold text-tide-deep">
                {statusLabel(g.status)}
              </span>
              <span className="font-mono text-[11px] text-tide-deep/45 tabular-nums">
                {g.tickets.length}
              </span>
            </header>
            <ul className="overflow-hidden rounded-[12px] bg-card shadow-tide divide-y divide-black/[0.05]">
              {g.tickets.map((t) => (
                <ListRow
                  key={t.id}
                  ticket={t}
                  onOpen={() => openTicket(t.id)}
                />
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}

function ListRow({
  ticket,
  onOpen,
}: {
  ticket: Ticket;
  onOpen(): void;
}) {
  const repo = useStore((s) =>
    ticket.repoId ? s.repos.find((r) => r.id === ticket.repoId) : null,
  );
  const updated = relTime(ticket.updatedAt);
  return (
    <li
      data-testid={`list-row-${ticket.title.replace(/\s+/g, "-")}`}
      onClick={onOpen}
      className="group flex items-center gap-3 px-3 py-2 hover:bg-black/[0.025] cursor-pointer"
    >
      <PriorityIcon value={ticket.priority} className="h-3 w-3 shrink-0" />
      <span className="font-mono tabular-nums text-[10.5px] text-tide-deep/55 w-[58px] shrink-0">
        TID-{ticket.id.slice(-4).toUpperCase()}
      </span>
      <span className="flex-1 truncate text-[13px] text-tide-deep">
        {ticket.title}
      </span>
      {ticket.planMode && (
        <span className="hidden sm:inline-flex items-center text-[10.5px] text-tide-sand">
          plan
        </span>
      )}
      {repo && (
        <span className="hidden md:inline-flex items-center font-mono text-[10.5px] text-tide">
          {repo.name}
        </span>
      )}
      {ticket.labels?.slice(0, 2).map((l) => (
        <span
          key={l.id}
          className="hidden md:inline-flex items-center text-[10.5px]"
          style={{ color: l.color }}
        >
          {l.name}
        </span>
      ))}
      {ticket.estimate && (
        <span className="font-mono text-[10.5px] text-tide-deep/55">
          {ticket.estimate}
        </span>
      )}
      <span className="w-[68px] shrink-0 text-right text-[10.5px] text-tide-deep/45 tabular-nums">
        {updated}
      </span>
    </li>
  );
}

function relTime(ms: number): string {
  const diff = Date.now() - ms;
  const m = Math.round(diff / 60_000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  const d = Math.round(h / 24);
  if (d < 14) return `${d}d`;
  const w = Math.round(d / 7);
  if (w < 8) return `${w}w`;
  const mo = Math.round(d / 30);
  return `${mo}mo`;
}
