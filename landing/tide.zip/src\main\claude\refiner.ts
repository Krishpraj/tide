// Plan-mode refiner: a lightweight, non-executing Claude invocation that
// improves a ticket's title + description and writes the result back to the
// ticket. Unlike the worker runner this does NOT check out a branch, run
// tools, or modify any files — it's pure text-in / text-out. The ticket
// stays in `triage` so the user can review the refinement and decide
// whether to queue it for real execution.

import { ticketsDao, eventsDao } from "../db/dao";
import { emit } from "../rpc/events";
import { surface } from "./surface";
import type { Ticket } from "@shared/types";

const REFINE_SYSTEM_PROMPT = [
  "You are refining a software-engineering ticket inside the Tide app.",
  "Your only job is to rewrite the ticket so a future engineer can act on it without ambiguity. Do NOT execute the work; do NOT read or modify files.",
  "Improve the title to be specific and outcome-oriented. Improve the description: clarify intent, surface assumptions, add structure (Context / Goal / Approach / Risks), and note any open questions.",
  "Output ONLY the refined ticket as markdown in exactly this shape, with no preamble or trailing commentary:",
  "",
  "# <refined title>",
  "",
  "<refined description in markdown — multiple paragraphs, headings, and bullet lists are fine>",
].join("\n");

/**
 * Fire-and-forget refinement. Returns a Promise but callers should not
 * block on it — the function emits ticketUpdated events when done.
 */
export async function refineTicket(ticketId: string): Promise<void> {
  const t = ticketsDao.get(ticketId);
  if (!t) return;

  const claudeBin = Bun.which("claude");
  if (!claudeBin) {
    surface(
      t.id,
      "refine skipped: claude CLI not found",
      "Install Claude Code to enable plan-mode refinement.",
      "warn",
    );
    return;
  }

  surface(t.id, "refining ticket (plan mode)");

  const userPrompt = `Refine this ticket:\n\n# ${t.title}\n\n${t.descriptionMd || "_(no description)_"}`;

  const cmd: string[] = [
    claudeBin,
    "-p",
    userPrompt,
    "--permission-mode",
    "plan",
    "--max-turns",
    "1",
    // Block every tool that could read/write files or stall on input.
    "--disallowed-tools",
    "AskUserQuestion ExitPlanMode EnterPlanMode Edit Write MultiEdit Bash Read Glob Grep WebFetch WebSearch NotebookEdit Task",
    "--append-system-prompt",
    REFINE_SYSTEM_PROMPT,
  ];

  try {
    const proc = Bun.spawn({
      cmd,
      cwd: process.cwd(),
      stdin: "ignore",
      stdout: "pipe",
      stderr: "pipe",
      env: { ...Bun.env },
    });

    const [out, err, code] = await Promise.all([
      new Response(proc.stdout).text(),
      new Response(proc.stderr).text(),
      proc.exited,
    ]);

    if (code !== 0) {
      const tail = err.trim().split(/\r?\n/).pop() || `exit ${code}`;
      surface(t.id, "refine failed", tail, "error");
      return;
    }

    const refined = out.trim();
    if (!refined) {
      surface(t.id, "refine produced no output", undefined, "warn");
      return;
    }

    const { title, body } = parseRefinement(refined, t);
    const doc = markdownToTipTapDoc(body);

    ticketsDao.update(t.id, {
      title,
      descriptionMd: body,
      description: JSON.stringify(doc),
    });

    eventsDao.insert({
      ticketId: t.id,
      kind: "refined",
      payload: { titleChanged: title !== t.title },
    });

    surface(t.id, "refine complete", title !== t.title ? `→ ${title}` : undefined);

    const updated = ticketsDao.get(t.id);
    if (updated) {
      emit("ticketUpdated", { ticket: ticketsDao.withLabels(updated) });
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    surface(t.id, "refine errored", msg, "error");
  }
}

/** Pull `# title\n\nbody` out of Claude's response. Falls back to the
 *  original title if Claude didn't follow the format. */
function parseRefinement(
  refined: string,
  original: Ticket,
): { title: string; body: string } {
  const m = /^\s*#\s+(.+?)\s*\n([\s\S]*)$/.exec(refined);
  if (m) {
    return { title: m[1]!.trim(), body: m[2]!.trim() };
  }
  return { title: original.title, body: refined };
}

/** Minimal markdown → TipTap JSON converter. Handles headings, bullet
 *  lists, and paragraphs (split on blank lines). Anything fancier (tables,
 *  code blocks with language hints, inline marks) becomes a plain
 *  paragraph — good enough for refinement output, and the user can edit
 *  further in the rich editor. */
function markdownToTipTapDoc(md: string): {
  type: "doc";
  content: unknown[];
} {
  const blocks = md.split(/\n{2,}/);
  const content: unknown[] = [];
  for (const raw of blocks) {
    const block = raw.trim();
    if (!block) continue;

    const heading = /^(#{1,6})\s+(.+)$/.exec(block);
    if (heading) {
      content.push({
        type: "heading",
        attrs: { level: heading[1]!.length },
        content: [{ type: "text", text: heading[2]! }],
      });
      continue;
    }

    const lines = block.split(/\r?\n/);
    if (lines.length > 0 && lines.every((l) => /^[-*]\s+/.test(l))) {
      content.push({
        type: "bulletList",
        content: lines.map((l) => ({
          type: "listItem",
          content: [
            {
              type: "paragraph",
              content: [
                { type: "text", text: l.replace(/^[-*]\s+/, "") },
              ],
            },
          ],
        })),
      });
      continue;
    }

    content.push({
      type: "paragraph",
      content: [{ type: "text", text: block }],
    });
  }
  return { type: "doc", content };
}
