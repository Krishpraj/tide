import {
  AlertCircle,
  Ban,
  CheckCircle2,
  Circle,
  CircleCheck,
  CircleDashed,
  CircleDot,
  Moon,
  XCircle,
  Inbox,
} from "lucide-react";
import type { Priority, TicketStatus } from "@shared/types";

export const STATUS_COLUMNS: TicketStatus[] = [
  "triage",
  "backlog",
  "queued",
  "in_progress",
  "review",
  "done",
];

export function statusLabel(s: TicketStatus): string {
  switch (s) {
    case "triage":
      return "Triage";
    case "backlog":
      return "Backlog";
    case "queued":
      return "Queued";
    case "in_progress":
      return "In Progress";
    case "review":
      return "Review";
    case "done":
      return "Done";
    case "discarded":
      return "Discarded";
    case "failed":
      return "Failed";
    case "canceled":
      return "Canceled";
    case "snoozed":
      return "Snoozed";
  }
}

export function StatusIcon({
  status,
  className,
}: {
  status: TicketStatus;
  className?: string;
}) {
  // Per-status tones from the design handoff (matches statust.* in tailwind).
  const cls = className ?? "h-3.5 w-3.5";
  switch (status) {
    case "triage":
      return <Inbox className={cls + " text-statust-triage"} />;
    case "backlog":
      return <Circle className={cls + " text-statust-backlog"} />;
    case "queued":
      return <CircleDashed className={cls + " text-statust-queued"} />;
    case "in_progress":
      return <CircleDot className={cls + " text-statust-progress"} />;
    case "review":
      return <CircleCheck className={cls + " text-statust-review"} />;
    case "done":
      return <CheckCircle2 className={cls + " text-statust-done"} />;
    case "discarded":
      return <XCircle className={cls + " text-tide-deep/35"} />;
    case "canceled":
      return <Ban className={cls + " text-tide-deep/35"} />;
    case "failed":
      return <AlertCircle className={cls + " text-destructive"} />;
    case "snoozed":
      return <Moon className={cls + " text-tide-deep/45"} />;
  }
}

export const PRIORITY_LABELS: Record<Priority, string> = {
  0: "No priority",
  1: "Low",
  2: "Medium",
  3: "High",
  4: "Urgent",
};

/**
 * Three vertical bars (height 3 / 6 / 9 px, 2.5 px wide), per design
 * handoff §Priority Indicator. Filled count = `4 - priority` (urgent=P1
 * fills all three; low=P4 fills none). The Tide data model uses 0..4
 * where 4=Urgent, so map first.
 */
export function PriorityIcon({
  value,
  className,
}: {
  value: Priority;
  className?: string;
}) {
  // Map Tide model (0=none, 4=urgent) → handoff "p" (1=urgent, 4=low).
  const p = value === 0 ? 4 : (5 - value) as 1 | 2 | 3 | 4;
  const filled = Math.max(0, Math.min(3, 4 - p));
  const bars = [3, 6, 9]; // heights
  return (
    <span
      data-priority={value}
      className={"inline-flex items-end gap-[2px] " + (className ?? "")}
      style={{ height: 11 }}
    >
      {bars.map((h, i) => (
        <span
          key={i}
          style={{
            width: 2.5,
            height: h,
            background:
              i < filled
                ? "hsl(var(--tide-deep))"
                : "rgba(0,0,0,0.13)",
            borderRadius: 1,
          }}
        />
      ))}
    </span>
  );
}

export function priorityColorClass(value: Priority): string {
  switch (value) {
    case 4:
      return "text-priority-urgent";
    case 3:
      return "text-priority-high";
    case 2:
      return "text-priority-medium";
    case 1:
      return "text-priority-low";
    default:
      return "text-priority-none";
  }
}
