import { useMemo, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  Folder,
  FolderOpen,
  Filter as FilterIcon,
  Archive,
  Moon,
  Plus,
  Sun,
} from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";
import { useStore, ticketInProject } from "../store";
import { useUiStore } from "../uistore";
import { STATUS_COLUMNS } from "../lib/status";
import { AddRepoDialog } from "./AddRepoDialog";
import { NewProjectDialog } from "./NewProjectDialog";

export function Sidebar() {
  const projects = useStore((s) => s.projects);
  const currentProjectId = useStore((s) => s.currentProjectId);
  const setCurrent = useStore((s) => s.setCurrentProject);
  const repos = useStore((s) => s.repos);
  const tickets = useStore((s) => s.tickets);
  const workers = useStore((s) => s.workers);

  const theme = useUiStore((s) => s.theme);
  const toggleTheme = useUiStore((s) => s.toggleTheme);
  const setViewMode = useUiStore((s) => s.setViewMode);
  const sidebarFilter = useUiStore((s) => s.sidebarFilter);
  const setSidebarFilter = useUiStore((s) => s.setSidebarFilter);
  const openTicket = useUiStore((s) => s.openTicket);

  const [addRepoOpen, setAddRepoOpen] = useState(false);
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  // File-tree style expand/collapse per project. Current project auto-
  // opens; others stay collapsed until clicked.
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  // Tickets in the current project. Counts derive from this so numbers
  // line up with what Board/List actually render.
  const scoped = useMemo(
    () => tickets.filter((t) => ticketInProject(t, repos, currentProjectId)),
    [tickets, repos, currentProjectId],
  );

  // "All tickets" = tickets you can actually see on the board (the board
  // only renders columns for STATUS_COLUMNS — triage..done). Discarded /
  // canceled / failed / snoozed are hidden, so they shouldn't pad this
  // number; the user would click All and see nothing.
  const visibleStatuses = useMemo(
    () => new Set<string>(STATUS_COLUMNS),
    [],
  );
  const allCount = useMemo(
    () => scoped.filter((t) => visibleStatuses.has(t.status)).length,
    [scoped, visibleStatuses],
  );
  const closedCount = useMemo(
    () =>
      scoped.filter((t) => t.status === "done" || t.status === "discarded")
        .length,
    [scoped],
  );

  const reposByProject = useMemo(() => {
    const m: Record<string, typeof repos> = {};
    for (const r of repos) {
      const key = r.projectId ?? "_orphan";
      (m[key] ??= []).push(r);
    }
    return m;
  }, [repos]);

  return (
    <aside
      data-testid="sidebar"
      className="w-[260px] shrink-0 border-r border-black/[0.05] bg-[hsl(var(--background))]/60 flex flex-col"
    >
      {/* Brand */}
      <div className="px-4 pt-4 pb-3 flex items-center gap-2 text-tide-deep">
        <TideLogo className="h-[22px] w-[22px]" />
        <span
          data-testid="tide-brand"
          className="text-[14px] font-semibold tracking-[-0.01em]"
        >
          Tide
        </span>
      </div>

      <ScrollArea className="flex-1 min-h-0">
        <div className="px-2 pb-2 space-y-3">
          {/* ───────── WORKSPACES ───────── */}
          <Section
            title="Workspaces"
            trailing={allCount}
            action={{
              label: "New project",
              onClick: () => setNewProjectOpen(true),
              testid: "new-project-menu-item",
            }}
          >
            {projects.map((p) => {
              const projectRepos = reposByProject[p.id] ?? [];
              const isCurrent = currentProjectId === p.id;
              // Default: current project is open; others are collapsed.
              // The user's explicit clicks override this default.
              const open =
                collapsed[p.id] !== undefined
                  ? !collapsed[p.id]
                  : isCurrent;
              return (
                <div
                  key={p.id}
                  className="group/project select-none"
                >
                  {/* Project row — file-explorer style: chevron + folder
                      glyph + name on the left, hover-revealed "+ add
                      repo" button on the right. Two siblings inside a div
                      (not nested <button>s) so each has its own click. */}
                  <div
                    className={
                      "flex items-center rounded-[6px] pl-1 pr-1 h-[26px] text-[12.5px] transition-colors " +
                      (isCurrent
                        ? "bg-tide-deep/[0.06] text-tide-deep font-medium"
                        : "text-tide-deep/75 hover:bg-black/[0.03]")
                    }
                  >
                    <button
                      type="button"
                      data-testid={`sidebar-project-${p.name}`}
                      onClick={() => {
                        setCurrent(p.id);
                        setCollapsed((s) => ({ ...s, [p.id]: open }));
                      }}
                      className="flex flex-1 min-w-0 items-center gap-1.5 text-left"
                    >
                      {open ? (
                        <ChevronDown className="h-3 w-3 text-tide-deep/45 shrink-0" />
                      ) : (
                        <ChevronRight className="h-3 w-3 text-tide-deep/45 shrink-0" />
                      )}
                      {open ? (
                        <FolderOpen className="h-3.5 w-3.5 text-tide-deep/55 shrink-0" />
                      ) : (
                        <Folder className="h-3.5 w-3.5 text-tide-deep/55 shrink-0" />
                      )}
                      <span className="truncate">{p.name}</span>
                    </button>
                    <button
                      type="button"
                      data-testid={`add-repo-${p.name}`}
                      aria-label={`add repo to ${p.name}`}
                      title="Add repo"
                      onClick={() => {
                        setCurrent(p.id);
                        setAddRepoOpen(true);
                      }}
                      className="inline-flex h-4 w-4 items-center justify-center rounded text-tide-deep/45 hover:bg-black/[0.05] hover:text-tide-deep opacity-0 group-hover/project:opacity-100 focus-visible:opacity-100 transition-opacity ml-1 shrink-0"
                    >
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  {open && projectRepos.length > 0 && (
                    <div className="ml-[10px] mt-px space-y-px border-l border-tide-deep/[0.06] pl-2">
                      {projectRepos.map((r) => {
                        const w = workers[r.id];
                        return (
                          <div
                            key={r.id}
                            data-testid={`sidebar-repo-${r.name}`}
                            className="group flex items-center gap-1.5 rounded-md px-1.5 h-[22px] hover:bg-black/[0.03] cursor-default"
                          >
                            <Folder className="h-3 w-3 text-tide-deep/35 shrink-0" />
                            <span className="flex-1 truncate text-[11.5px] text-tide-deep/65">
                              {r.name}
                            </span>
                            {w?.busy && (
                              <span
                                className="h-1.5 w-1.5 rounded-full bg-tide animate-pulse"
                                aria-label="busy"
                              />
                            )}
                            {w && w.queueLength > 0 && (
                              <span className="inline-flex h-3.5 min-w-[14px] items-center justify-center px-1 text-[10px] font-mono text-tide-deep/45">
                                {w.queueLength}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </Section>

          {/* ───────── FILTERS ───────── */}
          <Section title="Filters">
            <FilterItem
              icon={<FilterIcon className="h-3.5 w-3.5" />}
              label="All tickets"
              active={sidebarFilter === "all"}
              count={allCount}
              onClick={() => setSidebarFilter("all")}
              testid="filter-all"
            />
            <FilterItem
              icon={<Archive className="h-3.5 w-3.5" />}
              label="Recently closed"
              active={sidebarFilter === "recently_closed"}
              count={closedCount}
              onClick={() => {
                setSidebarFilter("recently_closed");
                // The board only has columns for triage..done — discarded
                // tickets are invisible there. List view groups every
                // status, so flip to it automatically.
                setViewMode("list");
                openTicket(null);
              }}
              testid="filter-recently-closed"
            />
          </Section>
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="border-t border-border px-3 py-2 flex items-center justify-end">
        <button
          onClick={toggleTheme}
          className="rounded p-1.5 text-tide-deep/45 hover:bg-black/[0.04] hover:text-tide-deep"
          aria-label="toggle theme"
          data-testid="theme-toggle"
        >
          {theme === "dark" ? (
            <Sun className="h-3.5 w-3.5" />
          ) : (
            <Moon className="h-3.5 w-3.5" />
          )}
        </button>
      </div>

      <AddRepoDialog open={addRepoOpen} onOpenChange={setAddRepoOpen} />
      <NewProjectDialog
        open={newProjectOpen}
        onOpenChange={setNewProjectOpen}
      />
    </aside>
  );
}

function Section({
  title,
  trailing,
  action,
  children,
}: {
  title: string;
  trailing?: React.ReactNode;
  action?: { label: string; onClick(): void; testid?: string };
  children: React.ReactNode;
}) {
  return (
    <div>
      {/* Section header — file-explorer style: title on the left, optional
          count + add-action on the right, thin hairline rule under to
          mark the divider. */}
      <div className="group/section flex items-center justify-between px-2 pt-3 pb-1.5 border-b border-tide-deep/[0.08] mb-1.5">
        <span className="text-[10.5px] font-semibold text-tide-deep/40">
          {title}
        </span>
        <div className="flex items-center gap-1.5">
          {trailing != null && trailing !== "" && (
            <span className="text-[10.5px] text-tide-deep/35 tabular-nums">
              {trailing}
            </span>
          )}
          {action && (
            <button
              type="button"
              onClick={action.onClick}
              aria-label={action.label}
              title={action.label}
              data-testid={action.testid}
              className="inline-flex h-4 w-4 items-center justify-center rounded text-tide-deep/45 hover:bg-black/[0.05] hover:text-tide-deep opacity-0 group-hover/section:opacity-100 focus-visible:opacity-100 transition-opacity"
            >
              <Plus className="h-3 w-3" />
            </button>
          )}
        </div>
      </div>
      <div className="space-y-px">{children}</div>
    </div>
  );
}

function FilterItem({
  icon,
  label,
  active,
  count,
  onClick,
  testid,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  count: number;
  onClick(): void;
  testid?: string;
}) {
  return (
    <button
      type="button"
      data-testid={testid}
      onClick={onClick}
      className={
        "w-full flex items-center gap-2 rounded-[6px] px-2 h-[26px] text-[12.5px] transition-colors " +
        (active
          ? "bg-tide-deep/[0.06] text-tide-deep font-medium"
          : "text-tide-deep/70 hover:bg-black/[0.03] hover:text-tide-deep")
      }
    >
      <span className={active ? "text-tide-deep" : "text-tide-deep/55"}>
        {icon}
      </span>
      <span className="truncate flex-1 text-left">{label}</span>
      <span className="font-mono text-[10.5px] tabular-nums text-tide-deep/40">
        {count}
      </span>
    </button>
  );
}

/**
 * Tide mark — modern SaaS-style logo. Squircle in the brand `tide`
 * accent (mid teal), with a single S-curve wave inside in oat. Uses the
 * exact same two colors as the rest of the app: the tide accent and
 * the oat surface.
 */
function TideLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect
        x="0"
        y="0"
        width="32"
        height="32"
        rx="8"
        fill="hsl(var(--tide))"
      />
      <path
        d="M 6 18 C 8.5 12.5, 13 12.5, 16 18 C 19 23.5, 23.5 23.5, 26 18"
        stroke="hsl(var(--background))"
        strokeWidth="2.4"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}
