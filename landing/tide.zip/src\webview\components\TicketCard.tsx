import { useState } from "react";
import { MoreHorizontal } from "lucide-react";
import { rpc } from "../rpc";
import { useStore } from "../store";
import { Badge } from "./ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { PriorityIcon, StatusIcon, statusLabel } from "../lib/status";
import type { Priority, Ticket, TicketStatus } from "@shared/types";

const STATUS_CHOICES: TicketStatus[] = [
  "backlog",
  "queued",
  "in_progress",
  "review",
  "done",
  "discarded",
  "canceled",
];

export function TicketCard({
  ticket,
  onOpen,
  selected,
  onSelectClick,
  draggable = true,
  showStatusIcon = false,
}: {
  ticket: Ticket;
  onOpen?: (id: string) => void;
  selected?: boolean;
  onSelectClick?: (e: React.MouseEvent) => void;
  draggable?: boolean;
  showStatusIcon?: boolean;
}) {
  const repo = useStore((s) =>
    ticket.repoId ? s.repos.find((r) => r.id === ticket.repoId) : null,
  );

  const shortId = `TID-${ticket.id.slice(-4).toUpperCase()}`;

  const updated = relTime(ticket.updatedAt);

  return (
    <div
      data-testid={`ticket-card-${ticket.title.replace(/\s+/g, "-")}`}
      data-ticket-id={ticket.id}
      data-selected={selected ? "true" : "false"}
      draggable={draggable}
      onDragStart={(e) => {
        e.dataTransfer.setData("text/x-tide-ticket", ticket.id);
        e.dataTransfer.effectAllowed = "move";
      }}
      onClick={onSelectClick}
      onDoubleClick={() => onOpen?.(ticket.id)}
      className={`group relative rounded-[10px] bg-white/95 backdrop-blur-[6px] border border-white/70 shadow-card-float hover:shadow-card-hover transition-shadow cursor-pointer ${
        selected ? "ring-1 ring-tide-deep/70" : ""
      }`}
      style={{ padding: "10px 12px 11px" }}
    >
      {/* Header row: priority · ID · status · plan · labels · updated */}
      <div className="flex items-center gap-[7px]">
        <PriorityIcon value={ticket.priority} className="shrink-0" />
        <span className="font-mono tabular-nums text-[10.5px] text-tide-deep/40">
          {shortId}
        </span>
        {showStatusIcon && (
          <StatusIcon status={ticket.status} className="h-3 w-3" />
        )}
        {ticket.planMode && (
          <span
            className="inline-flex items-center text-[10px] text-tide-sand"
            title="Plan-mode ticket"
          >
            plan
          </span>
        )}
        <span className="ml-auto inline-flex items-center gap-[6px]">
          <span className="font-mono text-[10.5px] text-tide-deep/40">
            {updated}
          </span>
          <CardActions ticket={ticket} />
        </span>
      </div>

      {/* Title */}
      <div
        className="mt-[8px] text-[12.5px] font-medium text-tide-deep line-clamp-2"
        style={{ lineHeight: 1.35 }}
      >
        {ticket.title}
      </div>

      {/* Footer row: repo · labels · estimate */}
      {(repo ||
        ticket.estimate ||
        (ticket.labels && ticket.labels.length > 0)) && (
        <div className="mt-[10px] flex items-center gap-2 flex-wrap">
          {repo && (
            <span
              data-testid="ticket-repo-badge"
              className="font-mono text-[10.5px] text-tide-deep/55"
            >
              {repo.name}
            </span>
          )}
          {ticket.labels?.map((l) => (
            <span
              key={l.id}
              data-testid={`ticket-label-${l.name}`}
              className="text-[10.5px]"
              style={{ color: l.color }}
            >
              {l.name}
            </span>
          ))}
          {ticket.estimate && (
            <span
              data-testid="ticket-estimate-badge"
              className="ml-auto font-mono text-[10px] text-tide-deep/55"
            >
              {ticket.estimate}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

function relTime(ms: number): string {
  const diff = Date.now() - ms;
  const m = Math.round(diff / 60_000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  const d = Math.round(h / 24);
  if (d < 14) return `${d}d`;
  const w = Math.round(d / 7);
  if (w < 8) return `${w}w`;
  const mo = Math.round(d / 30);
  return `${mo}mo`;
}

function CardActions({ ticket }: { ticket: Ticket }) {
  const repos = useStore((s) => s.repos);
  const labels = useStore((s) => s.labels);
  const [open, setOpen] = useState(false);

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          onClick={(e) => e.stopPropagation()}
          aria-label="ticket actions"
          data-testid="ticket-actions-trigger"
          className="opacity-0 group-hover:opacity-100 rounded p-0.5 text-tide-deep/55 hover:bg-black/[0.04] hover:text-tide-deep transition-opacity"
        >
          <MoreHorizontal className="h-3.5 w-3.5" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        onClick={(e) => e.stopPropagation()}
        data-testid="ticket-context-menu"
      >
        <DropdownMenuLabel>Status</DropdownMenuLabel>
        {STATUS_CHOICES.map((s) => (
          <DropdownMenuItem
            key={s}
            onSelect={() =>
              rpc.setStatus({ ticketId: ticket.id, status: s })
            }
            data-testid={`ticket-menu-status-${s}`}
          >
            <StatusIcon status={s} /> {statusLabel(s)}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuLabel>Priority</DropdownMenuLabel>
        {[0, 1, 2, 3, 4].map((p) => (
          <DropdownMenuItem
            key={p}
            onSelect={() =>
              rpc.setPriority({
                ticketId: ticket.id,
                priority: p as Priority,
              })
            }
            data-testid={`ticket-menu-priority-${p}`}
          >
            <PriorityIcon value={p as Priority} /> P{p}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuLabel>Repository</DropdownMenuLabel>
        <DropdownMenuItem
          onSelect={() =>
            rpc.assignTicket({ ticketId: ticket.id, repoId: null })
          }
        >
          <span className="text-muted-foreground">No repo</span>
        </DropdownMenuItem>
        {repos.map((r) => (
          <DropdownMenuItem
            key={r.id}
            onSelect={() =>
              rpc.assignTicket({ ticketId: ticket.id, repoId: r.id })
            }
            data-testid={`ticket-menu-repo-${r.name}`}
          >
            {r.name}
          </DropdownMenuItem>
        ))}
        {labels.length > 0 && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuLabel>Labels</DropdownMenuLabel>
            {labels.map((l) => {
              const active = ticket.labels?.some((x) => x.id === l.id);
              return (
                <DropdownMenuItem
                  key={l.id}
                  onSelect={() => {
                    const current = ticket.labels?.map((x) => x.id) ?? [];
                    const next = active
                      ? current.filter((id) => id !== l.id)
                      : [...current, l.id];
                    rpc.setLabels({ ticketId: ticket.id, labelIds: next });
                  }}
                >
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: l.color }}
                  />
                  {l.name} {active ? "✓" : ""}
                </DropdownMenuItem>
              );
            })}
          </>
        )}
        {ticket.status === "failed" && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              data-testid="ticket-menu-restart"
              onSelect={() => rpc.restartTicket(ticket.id)}
            >
              Restart
            </DropdownMenuItem>
          </>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          data-testid="ticket-menu-copy-branch"
          onSelect={() => {
            const branch =
              ticket.branchName ?? `tide/${slugify(ticket.title)}`;
            navigator.clipboard?.writeText(branch);
          }}
        >
          Copy branch name
        </DropdownMenuItem>
        <DropdownMenuItem
          data-testid="ticket-menu-duplicate"
          onSelect={() => rpc.duplicateTicket(ticket.id)}
        >
          Duplicate
        </DropdownMenuItem>
        <DropdownMenuItem
          data-testid="ticket-menu-delete"
          onSelect={() => rpc.deleteTicket(ticket.id)}
          className="text-destructive focus:text-destructive"
        >
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}
