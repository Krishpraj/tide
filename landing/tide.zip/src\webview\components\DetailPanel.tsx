import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { useUiStore } from "../uistore";

/**
 * Slide-in 440px panel from the right (handoff §Ticket Detail Panel).
 * - Backdrop: rgba(0,0,0,.18) + 2px blur, fade .18s ease
 * - Panel: slide .22s cubic-bezier(.2,.7,.3,1), shadow `-8px 0 32px rgba(0,0,0,.08)`
 *
 * Wraps whatever the caller passes as children — currently <ReviewPanel>
 * with all its activity / diff / live stream / merge / iterate behavior.
 * The detail panel itself only owns the chrome (backdrop, slide,
 * close button), not the contents.
 */
export function DetailPanel({
  ticketId,
  children,
}: {
  ticketId: string | null;
  children: React.ReactNode;
}) {
  const openTicket = useUiStore((s) => s.openTicket);
  const open = ticketId !== null;

  // Keep `children` mounted for a short tail after close so the slide-out
  // animation has something to render. `visible` flips immediately; `mounted`
  // lingers until the exit animation finishes.
  const [mounted, setMounted] = useState(open);
  useEffect(() => {
    if (open) {
      setMounted(true);
      return;
    }
    const t = setTimeout(() => setMounted(false), 230);
    return () => clearTimeout(t);
  }, [open]);

  // Esc to close.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") openTicket(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, openTicket]);

  if (!mounted) return null;

  return (
    <>
      <div
        data-testid="detail-backdrop"
        onClick={() => openTicket(null)}
        className={
          "absolute inset-0 z-40 bg-black/[0.18] backdrop-blur-[2px] " +
          (open ? "tide-backdrop-in" : "tide-backdrop-out")
        }
      />
      <aside
        data-testid="detail-panel"
        role="dialog"
        aria-modal="true"
        className={
          "absolute right-0 top-0 bottom-0 z-50 w-[min(440px,92vw)] bg-card border-l border-black/[0.05] shadow-panel-detail flex flex-col overflow-hidden " +
          (open ? "tide-panel-in" : "tide-panel-out")
        }
      >
        <button
          type="button"
          aria-label="close"
          data-testid="detail-close"
          onClick={() => openTicket(null)}
          className="absolute right-2.5 top-2.5 z-10 inline-flex h-7 w-7 items-center justify-center rounded-[7px] text-tide-deep/55 hover:bg-black/[0.05] hover:text-tide-deep"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="flex-1 min-h-0 flex flex-col">{children}</div>
      </aside>
    </>
  );
}
