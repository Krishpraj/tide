import { useEffect, useState } from "react";
import {
  LayoutGrid,
  LayoutList,
  CalendarDays,
  Search,
  Settings,
} from "lucide-react";
import { useStore } from "../store";
import { useUiStore, type ViewMode } from "../uistore";
import { NotificationBell } from "./NotificationBell";

/**
 * Top nav — handoff §Top Nav. Layout: breadcrumb on the left, segmented
 * view toggle next to it, search pill stretched to the right with bell +
 * gear at the far edge.
 */
export function TopChrome() {
  const currentProject = useStore((s) =>
    s.projects.find((p) => p.id === s.currentProjectId),
  );
  const viewMode = useUiStore((s) => s.viewMode);
  const setViewMode = useUiStore((s) => s.setViewMode);
  const setCommandOpen = useUiStore((s) => s.setCommandOpen);
  const openTicket = useUiStore((s) => s.openTicket);
  const [mac, setMac] = useState(false);

  useEffect(() => {
    setMac(/Mac|iPhone|iPad/.test(navigator.platform));
  }, []);

  const items: { id: ViewMode; icon: React.ReactNode; label: string }[] = [
    { id: "board", icon: <LayoutGrid className="h-3.5 w-3.5" />, label: "Board" },
    { id: "list", icon: <LayoutList className="h-3.5 w-3.5" />, label: "List" },
    {
      id: "calendar",
      icon: <CalendarDays className="h-3.5 w-3.5" />,
      label: "Calendar",
    },
  ];

  return (
    <div
      data-testid="top-chrome"
      className="flex items-center gap-3 border-b border-black/[0.05] bg-transparent px-[22px] h-[52px] shrink-0"
    >
      {/* Breadcrumb — just the current project */}
      <nav className="flex items-center gap-1.5 text-[13px] min-w-0">
        <span className="font-medium text-tide-deep truncate">
          {currentProject?.name ?? "No project"}
        </span>
      </nav>

      {/* Segmented view toggle */}
      <div
        data-testid="view-toggle"
        className="inline-flex items-center gap-0.5 rounded-[8px] bg-black/[0.04] p-0.5"
      >
        {items.map((it) => {
          const active = viewMode === it.id;
          return (
            <button
              key={it.id}
              type="button"
              data-testid={`view-${it.id}`}
              aria-current={active ? "page" : undefined}
              onClick={() => {
                setViewMode(it.id);
                openTicket(null);
              }}
              className={
                "inline-flex items-center gap-1.5 h-7 px-2.5 rounded-[6px] text-[12.5px] transition-colors " +
                (active
                  ? "bg-white text-tide-deep shadow-seg-active font-medium"
                  : "text-tide-deep/55 hover:text-tide-deep")
              }
            >
              <span className={active ? "text-tide-deep" : "text-tide-deep/55"}>
                {it.icon}
              </span>
              {it.label}
            </button>
          );
        })}
      </div>

      {/* Search pill — stretched to the right */}
      <button
        type="button"
        data-testid="top-search"
        onClick={() => setCommandOpen(true)}
        className="ml-auto group inline-flex items-center gap-2 h-[30px] min-w-[260px] rounded-[8px] border border-black/[0.06] bg-black/[0.035] px-2.5 text-[12.5px] text-tide-deep/55 hover:text-tide-deep hover:bg-black/[0.05] transition-colors"
      >
        <Search className="h-[13px] w-[13px] text-tide-deep/45 group-hover:text-tide" />
        <span className="flex-1 text-left">Search or jump to…</span>
        <kbd className="inline-flex items-center rounded bg-white px-1.5 py-[2px] font-mono text-[10.5px] text-tide-deep/55 border border-black/[0.08]">
          {mac ? "⌘K" : "Ctrl+K"}
        </kbd>
      </button>

      <NotificationBell />

      <button
        type="button"
        aria-label="settings"
        className="inline-flex h-[30px] w-[30px] items-center justify-center rounded-[7px] text-tide-deep/65 hover:text-tide-deep hover:bg-black/[0.04]"
      >
        <Settings className="h-[15px] w-[15px]" />
      </button>
    </div>
  );
}
